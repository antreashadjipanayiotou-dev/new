
let demos = [
  { id: 1, title: 'Θεσσαλονίκη', subtitle: 'Νέο demo', audioSrc: null, isPlaying: false, duration: 168 }
];

let audioElements = {};

function init() {
  renderDemos();
  document.getElementById('demo-file').addEventListener('change', function(e) {
    if(e.target.files.length > 0) {
      document.getElementById('file-name').innerText = e.target.files[0].name;
    }
  });
}

function renderDemos() {
  const container = document.getElementById('demos-container');
  container.innerHTML = '';
  
  demos.forEach(demo => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="card-header">
        <h3>${demo.title}</h3>
        <p>${demo.subtitle}</p>
      </div>
      <div class="player-controls">
        <button class="play-btn" onclick="togglePlay(${demo.id})">
          <i class="fas fa-${demo.isPlaying ? 'pause' : 'play'}" id="icon-${demo.id}"></i>
        </button>
        <span class="time" id="time-${demo.id}">0:00 / 2:48</span>
        <input type="range" class="progress-bar" id="progress-${demo.id}" value="0" step="0.1" min="0" max="100">
        <i class="fas fa-volume-up" style="color:var(--text-muted)"></i>
        <i class="fas fa-ellipsis-v" style="color:var(--text-muted); margin-left:10px;"></i>
      </div>
      <div class="card-actions">
        <button class="btn-outline"><i class="fas fa-external-link-alt"></i> Άνοιγμα ήχου</button>
        <button class="btn-primary"><i class="fas fa-envelope"></i> Ενδιαφέρομαι</button>
      </div>
    `;
    container.appendChild(card);
    
    if (demo.audioSrc && !audioElements[demo.id]) {
      const audio = new Audio(demo.audioSrc);
      audioElements[demo.id] = audio;
      
      audio.addEventListener('timeupdate', () => {
         const progress = (audio.currentTime / audio.duration) * 100;
         const pBar = document.getElementById(`progress-${demo.id}`);
         if(pBar) pBar.value = progress;
         const tBar = document.getElementById(`time-${demo.id}`);
         if(tBar) tBar.innerText = `${formatTime(audio.currentTime)} / ${formatTime(audio.duration || 0)}`;
      });
      audio.addEventListener('ended', () => {
         demo.isPlaying = false;
         const icon = document.getElementById(`icon-${demo.id}`);
         if(icon) icon.className = 'fas fa-play';
      });
    }
  });
}

function formatTime(seconds) {
  if(isNaN(seconds)) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

function togglePlay(id) {
  const demo = demos.find(d => d.id === id);
  const audio = audioElements[id];
  const icon = document.getElementById(`icon-${id}`);
  
  if (!audio) {
    alert("Αυτό είναι το προεπιλεγμένο demo. Πρόσθεσε δικό σου MP3 από το κουμπί 'Διαχείριση' απευθείας από το κινητό σου!");
    return;
  }

  if (demo.isPlaying) {
    audio.pause();
    demo.isPlaying = false;
    icon.className = 'fas fa-play';
  } else {
    demos.forEach(d => {
       if(d.id !== id && d.isPlaying) {
         audioElements[d.id].pause();
         d.isPlaying = false;
         document.getElementById(`icon-${d.id}`).className = 'fas fa-play';
       }
    });
    audio.play();
    demo.isPlaying = true;
    icon.className = 'fas fa-pause';
  }
}

function toggleAdmin() {
  const modal = document.getElementById('admin-modal');
  modal.style.display = modal.style.display === 'flex' ? 'none' : 'flex';
}

function addDemo() {
  const title = document.getElementById('demo-title').value;
  const subtitle = document.getElementById('demo-subtitle').value;
  const fileInput = document.getElementById('demo-file');
  
  if(!title || fileInput.files.length === 0) {
    alert("Παρακαλώ συμπληρώστε τίτλο και επιλέξτε αρχείο MP3.");
    return;
  }

  const file = fileInput.files[0];
  const audioSrc = URL.createObjectURL(file);

  const newDemo = {
    id: Date.now(),
    title: title,
    subtitle: subtitle || 'Νέο demo',
    audioSrc: audioSrc,
    isPlaying: false
  };

  demos.unshift(newDemo);
  renderDemos();
  toggleAdmin();
  
  document.getElementById('demo-title').value = '';
  document.getElementById('demo-subtitle').value = '';
  fileInput.value = '';
  document.getElementById('file-name').innerText = '';
}

window.onload = init;
